const MoneyToken = artifacts.require("MoneyToken");
const web3 = require("web3");

module.exports = function(deployer) {
  deployer.deploy(MoneyToken, 'MyToken', 'MTK', web3.utils.toWei('100000000'));
};
