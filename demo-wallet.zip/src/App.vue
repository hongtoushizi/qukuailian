<template>
  <div id="nav">
    <router-link to="/">钱包</router-link> |
    <router-link to="/explore">发现</router-link> |
    <router-link to="/center">我的</router-link>
  </div>
  <router-view />
</template>
<script>
  import store from '@/store'
export default {
  name: 'App',
  beforeCreate() {
    store.dispatch('registerWeb3')
  }
}

</script>
<style type="text/css"></style>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}

</style>
