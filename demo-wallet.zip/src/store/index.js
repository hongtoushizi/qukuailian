import { createStore } from 'vuex'
import Web3 from 'web3'
// import { registerWeb3 } from '@/utils/getWeb3.js'

export default createStore({
  state: {
    web3: {
      instance: null,
      provider: null
    },

    account: {
      address: null,
      balanceOf: 0
    }
  },

  mutations: {
    registerWeb3(state, web3) {
      state.web3 = web3
    },
    changeAccount(state, account) {
      state.account = account
    }
  },

  actions: {
    registerWeb3: function({ commit }) {
      console.log('registerWeb3')
      // 代码封装
      let provider
      if (window.ethereum) {
        provider = window.ethereum
        // try {
        //   // Request account access
        //   window.ethereum.request({ method: 'eth_requestAccounts' }).then(account => {
        //     commit('changeAccount', account[0])
        //   })
        // } catch (error) {
        //   // User denied account access...
        //   console.error("User denied account access")
        // }
      }
      // Legacy dapp browsers...
      else if (window.web3) {
        provider = window.web3.currentProvider
      }
      // If no injected web3 instance is detected, fall back to Ganache
      else {
        provider = new Web3.providers.HttpProvider('http://localhost:7545');
      }

      const instance = new Web3(provider)

      commit('registerWeb3', { instance, provider })
    }
  },

  modules: {}
})
