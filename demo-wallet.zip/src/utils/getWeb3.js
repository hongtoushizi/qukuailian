import Web3 from 'web3'
// import Contract from 'web3-eth-contract'
// import store from '@/store'
// import BigInteger from 'big-integer'

export const registerWeb3 = () => {
  // 代码封装
  let provider
  if (window.ethereum) {
    provider = window.ethereum
  }
  // Legacy dapp browsers...
  else if (window.web3) {
    provider = window.web3.currentProvider
  }
  // If no injected web3 instance is detected, fall back to Ganache
  else {
    provider = new Web3.providers.HttpProvider('http://localhost:7545');
  }

  const web3 = new Web3(provider)

  return { web3, provider }
}
