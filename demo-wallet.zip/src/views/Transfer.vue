<template>
  <div class="transfer">
    transfer
  </div>
</template>
<script>
// @ is an alias to /src

export default {
  name: 'Home',
  components: {}
}

</script>
<style lang="scss" scoped>
.home {
  width: 480px;
  margin: 0 auto;
}

</style>
