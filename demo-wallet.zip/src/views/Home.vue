<template>
  <div class="home">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>账户信息</span>
          <span class="account">{{account}}</span>
        </div>
      </template>
      <div class="item">
        <p>可用余额({{symbol}})</p>
        <b class="balance">{{balance}} </b>
      </div>
    </el-card>
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>账户转账</span>
        </div>
      </template>
      <el-form :model="transferForm" label-position="top" class="demo-form-inline">
        <el-form-item label="数额">
          <el-input v-model="transferForm.value"></el-input>
        </el-form-item>
        <el-form-item label="接受者">
          <el-input v-model="transferForm.to"></el-input>
        </el-form-item>
        <el-form-item label="燃料价格(GWEI)">
          <el-input v-model="transferForm.gasPrice"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="transfer">确定转账</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>
<script>
import { mapState } from 'vuex'
import Web3 from 'web3'
// import Contract from 'web3-eth-contract'
import MoneyToken from '@/abis/MoneyToken.json'

export default {
  name: 'Wallet',
  data() {
    return {
      symbol: '',
      account: '',
      balance: 0,
      transferForm: {
        to: '',
        value: 0,
        gasPrice: '20'
      }
    }
  },
  async created() {
    // 初始化合约
    // console.log(this.web3)
    const { web3Instance } = this
    const accounts = await web3Instance.eth.getAccounts()
    this.account = accounts[0]

    this.initContract(web3Instance, MoneyToken).then(contract => {
      this.getTokenSymbol(contract).then(symbol => this.symbol = symbol)
      this.getBalanceOf(contract, this.account).then(balance => {
        console.log(`balanceOf[owner] = ${balance}`)
        this.balance = (+Web3.utils.fromWei(balance)).toFixed(2)
      })
    })
  },
  methods: {
    initContract(web3, { abi, networks }) {
      return web3.eth.net.getId().then(network_id => {
        console.log(`network_id = ${network_id}`)
        return new web3.eth.Contract(abi, networks[network_id].address)
      })
    },
    getTokenSymbol(contract) {
      return contract.methods.symbol().call()
    },

    getBalanceOf(contract, account) {
      // coding
      return contract.methods.balanceOf(account).call()
    },

    // 用户转账
    transfer() {
      const { to, value, gasPrice } = this.transferForm
      const from = this.account

      // 用到的变量
      console.log({ from, to, value, gasPrice })

      this.initContract(this.web3Instance, MoneyToken).then(contract => {
        contract
        // contract = await Token.deployed()

        // +----------------------------------------------------------------------
        // | 在这里编写监听转账事件
        // https://learnblockchain.cn/docs/web3.js/web3-eth-contract.html#id47
        // +----------------------------------------------------------------------


        // +----------------------------------------------------------------------
        // | 在这里编写转账代码
        // https://learnblockchain.cn/docs/web3.js/web3-eth-contract.html#id62
        // +----------------------------------------------------------------------



        // 结束
      })
    }
  },

  computed: {
    ...mapState({
      web3Instance: state => state.web3.instance,
      web3Provider: state => state.web3.provider
    })
  }
}

</script>
<style lang="scss" scoped>
.home {
  max-width: 480px;
  margin: 0 auto;
}

.box-card+.box-card {
  margin-top: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.item {
  padding-top: 16px;
  padding-bottom: 20px;
}

.account {
  font-size: 12px;
}

.balance {
  font-size: 28px;

  small {
    font-size: 14px;
  }
}

</style>
