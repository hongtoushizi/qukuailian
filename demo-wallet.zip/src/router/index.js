import { createRouter, createWebHistory } from 'vue-router'

// import store from '@/store'
// import { registerWeb3 } from '@/utils/getWeb3.js'

import Home from '@/views/Home.vue'
import About from '@/views/About.vue'
import Transfer from '@/views/Transfer.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/transfer',
    name: 'transfer',
    component: Transfer
  },
  {
    path: '/explore',
    name: 'Explore',
    component: About
  },
  {
    path: '/center',
    name: 'Center',
    component: About
  },
  {
    path: '/about',
    name: 'About',
    component: About
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

// 检查环境
// router.beforeEach((to, from, next) => {
//   const { state, commit } = store
//   if (state.web3.privoder) {
//     next()
//   } else {
//     const result = registerWeb3()
//     commit('registerWeb3', result)
//     // next()
//   }
// })
export default router
