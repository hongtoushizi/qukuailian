# vue-wallet

## Truffle setup
````
> truffle compile 
> truffle migrate --reset --network ropsten

```
## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Code Path
````
./src/views/Home.vue

```